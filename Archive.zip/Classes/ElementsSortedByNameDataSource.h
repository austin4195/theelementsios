
@import UIKit;

#import "ElementsDataSourceProtocol.h"

@interface ElementsSortedByNameDataSource : NSObject <UITableViewDataSource, ElementsDataSource> {
}

@end
