
@import UIKit;

@interface TheElementsAppDelegate : NSObject  <UIApplicationDelegate>


@end
