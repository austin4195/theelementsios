
@import UIKit;

@class AtomicElement;

@interface AtomicElementTileView : UIView

@property (nonatomic, strong) AtomicElement *element;

@end
