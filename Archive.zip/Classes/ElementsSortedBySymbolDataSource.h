

@import UIKit;
#import "ElementsDataSourceProtocol.h"

@interface ElementsSortedBySymbolDataSource : NSObject <UITableViewDataSource,ElementsDataSource> {
}
 
@end
