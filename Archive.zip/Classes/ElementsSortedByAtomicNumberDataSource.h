

@import UIKit;

#import "ElementsDataSourceProtocol.h"

@interface ElementsSortedByAtomicNumberDataSource : NSObject <UITableViewDataSource,ElementsDataSource> {
}

@end
