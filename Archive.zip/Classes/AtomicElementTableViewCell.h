
@import UIKit;

@class AtomicElement;

@interface AtomicElementTableViewCell : UITableViewCell

@property (nonatomic,strong) AtomicElement *element;

@end
