/*
Copyright (C) 2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Displays the Atomic Element information with a link to Wikipedia.
*/

@import UIKit;
#import "AtomicElementView.h"

@interface AtomicElementFlippedView : AtomicElementView

@end
