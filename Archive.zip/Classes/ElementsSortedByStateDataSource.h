

@import UIKit;
#import "ElementsDataSourceProtocol.h"

@interface ElementsSortedByStateDataSource : NSObject <UITableViewDataSource,ElementsDataSource> {
}

@end
 